alert(1); 
console.log(1)